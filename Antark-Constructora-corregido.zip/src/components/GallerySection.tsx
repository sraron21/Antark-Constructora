import React, { useEffect, useState } from 'react';

const PHOTOS = [
  { src: '/img/vista-aerea-2.webp', alt: 'Vista aérea de las calles y viviendas del Residencial Germán Rázuri', cap: 'Vista aérea del residencial', wide: true },
  { src: '/img/calle-dia.webp', alt: 'Calle asfaltada y bloque de viviendas de dos pisos', cap: 'Calles y viviendas' },
  { src: '/img/calle-noche.webp', alt: 'Calle del residencial con alumbrado público al atardecer', cap: 'Alumbrado público' },
  { src: '/img/bloque-areas-verdes.webp', alt: 'Bloque de viviendas frente a áreas verdes con sendero', cap: 'Áreas verdes' },
  { src: '/img/obra-aerea.webp', alt: 'Vista aérea del avance de obra de una etapa del residencial', cap: 'Avance de obra' },
];

export function GallerySection() {
  const [open, setOpen] = useState<number | null>(null);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(null);
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  return (
    <section id="galeria" className="w-full py-20 bg-[#f7f9fb] scroll-mt-12">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <h2 className="font-['Outfit',sans-serif] text-3xl md:text-4xl font-bold text-[#000f22] mb-3">Conoce el residencial</h2>
        <p className="text-[#43474d] max-w-2xl mb-10">Fotografías reales del Residencial Germán Rázuri en San Pedro de Lloc.</p>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 md:gap-4 auto-rows-[160px] md:auto-rows-[220px]">
          {PHOTOS.map((p, i) => (
            <button
              key={p.src}
              onClick={() => setOpen(i)}
              className={`group relative overflow-hidden rounded-2xl text-left focus:outline-none focus-visible:ring-4 focus-visible:ring-[#a13e28]/50 ${p.wide ? 'col-span-2 row-span-2' : ''}`}
            >
              <img decoding="async" loading="lazy" src={p.src} alt={p.alt} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
              <span className="absolute inset-x-0 bottom-0 p-3 text-sm font-semibold text-white bg-gradient-to-t from-black/70 to-transparent translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 group-focus-visible:opacity-100 transition-all duration-300">{p.cap}</span>
            </button>
          ))}
        </div>
        <p className="text-xs text-[#43474d] mt-4">Imágenes referenciales del proyecto y su avance.</p>
      </div>
      {open !== null && (
        <div role="dialog" aria-modal="true" aria-label={PHOTOS[open].cap} onClick={() => setOpen(null)} className="fixed inset-0 z-50 bg-[#000f22]/90 flex items-center justify-center p-4 cursor-zoom-out">
          <img src={PHOTOS[open].src} alt={PHOTOS[open].alt} className="max-h-[88vh] max-w-full rounded-xl shadow-2xl" />
          <button aria-label="Cerrar" className="absolute top-4 right-5 text-white text-4xl leading-none">&times;</button>
        </div>
      )}
    </section>
  );
}
